// Function to handle slide navigation
function showSlide(slideId) {
    // Get all slides
    const slides = document.querySelectorAll('.slide');
    
    // Hide all slides
    slides.forEach(slide => {
        slide.classList.remove('active');
    });
    
    // Show the selected slide
    const activeSlide = document.getElementById(slideId);
    if (activeSlide) {
        activeSlide.classList.add('active');
    }
}

// Add event listeners to slide links
const slideLinks = document.querySelectorAll('.slide-link');
slideLinks.forEach(link => {
    link.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent default anchor behavior
        const targetId = this.getAttribute('href').substring(1); // Get the target slide ID
        showSlide(targetId); // Show the corresponding slide
    });
});

// Show the Home slide by default when the page loads
document.addEventListener('DOMContentLoaded', () => {
    showSlide('home');
});
